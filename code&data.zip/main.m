% In the simulation, the center wave length is set as 500nm, the pitch size
% of the SPAD image sensor is assumed to be 10um. We take the center wave
% length as the unit of length.


%% product state with opposite OAM quantum number
if 0 
clc;clear;
load('NENU.mat');
para.nenu = nenu;


m=0; para.m = m;% OAM quantum number
lambda = 1; % center wave length of the pulse
thetac = 0.001*pi; para.thetac = thetac; %polar angle of the bessel pulse
sigmaz = 1000; para.sigmaz = sigmaz;% pulse length in units of lambda
sigmar = 1000; para.sigmar = sigmar;% pulse cross-section size in units of lambda

pitch = 20;para.pitch = pitch; % pitch size of the camera in units of lambda
nrow = 51; para.nrow=nrow; % number of rows
ncol = 51; para.ncol = ncol;% number of colums





PND = zeros(nrow,ncol);
I1_mat = zeros(nrow,ncol);
Cd_mat = zeros(nrow,ncol);
Sd_mat = zeros(nrow,ncol);

for i =1:nrow 
     x = -pitch*(nrow-1)/2+i*20;
 
     for j = 1:ncol
         y = pitch*(ncol-1)/2-j*20;
         zeta1 =  Zeta(para,x,y);
         PND(i,j) = zeta1;
         I1_mat(i,j) = zeta1 * phasefactor(para,i,j);

     end

end

I1 = pitch^2 * sum(sum(I1_mat));

Ptot = pitch^2 * sum(sum(PND));

for i = 1: nrow
    for j= 1:ncol
        zeta1 = PND(i,j);
        Cd_mat(i,j) = (1/4)*zeta1*real( 2- (I1/Ptot)*phasefactor(para,i,j)'-(I1/Ptot)'*phasefactor(para,i,j) );
        Sd_mat(i,j) = -(1/4)*real((I1/Ptot)*phasefactor(para,i,j)'+(I1/Ptot)'*phasefactor(para,i,j) );
    end
    
end

% save(['./Data_product1_m=' num2str(m) '.mat'],'para','PND','I1_mat','I1','Ptot',...
%     'Cd_mat','Sd_mat','-v7.3');


figure(1);
imagesc(PND*1e5);% xlim([350,450]); ylim([250,350]);
figure(2)
imagesc(Cd_mat*1e5)
figure(3)
imagesc(Sd_mat*1e5)

end

%% %% product state with the same OAM quantum number
if 0 
clc;clear;
load('NENU.mat');
para.nenu = nenu;


m=2; para.m = m;% OAM quantum number
lambda = 1; % center wave length of the pulse
thetac = 0.01*pi; para.thetac = thetac; %polar angle of the bessel pulse
sigmaz = 1000; para.sigmaz = sigmaz;% pulse length in units of lambda
sigmar = 10000; para.sigmar = sigmar;% pulse cross-section size in units of lambda

pitch = 20;para.pitch = pitch; % pitch size of the camera in units of lambda
nrow = 51; para.nrow=nrow; % number of rows
ncol = 51; para.ncol = ncol;% number of colums





PND = zeros(nrow,ncol);
I3_mat = zeros(nrow,ncol);
Cd_mat = zeros(nrow,ncol);
Sd_mat = zeros(nrow,ncol);

for i =1:nrow 
     x = -pitch*(nrow-1)/2+i*20;
 
     for j = 1:ncol
         y = pitch*(ncol-1)/2-j*20;
         zeta1 =  Zeta(para,x,y);
         PND(i,j) = zeta1;
         I3_mat(i,j) = zeta1 * phasefactorm(para,i,j);

     end

end


Ptot = pitch^2 * sum(sum(PND));
I3n = pitch^2 * sum(sum(I3_mat));


for i = 1: nrow
    for j= 1:ncol
        zeta1 = PND(i,j);
        Cd_mat(i,j) = (1/4)*zeta1*real( 2- (I3n/Ptot)*phasefactorm(para,i,j)'-(I3n/Ptot)'*phasefactorm(para,i,j) );
        Sd_mat(i,j) = -(1/4)*real((I3n/Ptot)*phasefactorm(para,i,j)'+(I3n/Ptot)'*phasefactorm(para,i,j) );
    end
    
end

save(['./Data_product2_m=' num2str(m) '.mat'],'para','PND','I3_mat','I3n','Ptot',...
    'Cd_mat','Sd_mat','-v7.3');


figure(1);
imagesc(PND*1e5);% xlim([350,450]); ylim([250,350]);
figure(2)
imagesc(Cd_mat*1e5)
figure(3)
imagesc(Sd_mat*1e5)

end

