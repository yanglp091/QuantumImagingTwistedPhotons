w_p = 0.3; h_p =0.38;
mlist =1:3;
nphi =808;nrho=1024;
philist=linspace(-pi,pi,nphi);
rholist=linspace(0.01,1,nrho);
g2mat = zeros(nrho,nphi);
g2cell = cell(2,3);
for n=1:3
    m = mlist(n);
    
    for j=1:nrho  
        for k =1:nphi
           phi = philist(k);
           g2mat(j,k) = 0.5*(1+cos(2*m*(phi)+2*Pxy2(j,k)));
        end  
    end

    g2cell{1,n} = g2mat;

    for j=1:nrho  
        for k =1:nphi
           phi = philist(k);
           g2mat(j,k) = 0.5*(1-cos(2*m*(phi)+2*Pxy2(j,k)));
        end  
    end

    g2cell{2,n} = g2mat;

end

[phi,rho]=meshgrid(philist,rholist);
[X,Y] = pol2cart(phi, rho);
Z =  0*ones(size(X));

%%      m = 1 symmetrized state

subplot('position',[0.01,0.55,w_p,h_p])                     
surf(X,Y,g2cell{1,1})
shading interp;
view([0,90]);
colormap(gray);
% colormap(flipud(gray));
grid off;
set(gca,'Visible','off');


   
%%     m =2 symmetrized state
subplot('position',[0.33,0.55,w_p,h_p])                     
surf(X,Y,g2cell{1,2})
shading interp;
view([0,90]);
colormap(gray);
% colormap(flipud(gray));
grid off;
set(gca,'Visible','off');


%%  m = 3 symmetrized state
subplot('position',[0.65,0.55,w_p,h_p])                     
surf(X,Y,g2cell{1,3})
shading interp;
view([0,90]);
colormap(gray);
% colormap(flipud(gray));
grid off;
set(gca,'Visible','off');

%%      m = 1 anti-symmetrized state

subplot('position',[0.01,0.15,w_p,h_p])                     
surf(X,Y,g2cell{2,1})
shading interp;
view([0,90]);
colormap(gray);
% colormap(flipud(gray));
grid off;
set(gca,'Visible','off');


   
%%     m =2 anti-symmetrized state
subplot('position',[0.33,0.15,w_p,h_p])                     
surf(X,Y,g2cell{2,2})
shading interp;
view([0,90]);
colormap(gray);
% colormap(flipud(gray));
grid off;
set(gca,'Visible','off');


%%  m = 3 anti-symmetrized state
subplot('position',[0.65,0.15,w_p,h_p])                     
surf(X,Y,g2cell{2,3})
shading interp;
view([0,90]);
colormap(gray);
% colormap(flipud(gray));
grid off;
set(gca,'Visible','off');

h=colorbar('Ticks',0:0.2:1,'TickLabels','');
set(h,'location','east','position',[0.9765 0.33 0.02 0.4]);
set(h,'TickLength',0.04,'Linewidth',2,'color',[0.871,0.49,0])

set(gcf,'PaperSize',[21 16],'PaperPosition',[0.5, 0.5, 20, 15]);

% end