clear;clc;
I = imread('./NENU.png');
  image(I);
f = im2double(I); 
data = vecnorm3(f);
data = 2*pi*data/max(max(data));
save('./NENU.mat','data','-v7.3');

% f_r=f(:,:,1);
% f_b=f(:,:,2);
% f_g=f(:,:,3);


