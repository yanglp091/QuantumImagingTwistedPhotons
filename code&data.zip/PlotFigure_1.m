

%%  texture of PND, current, velocity, OAM density 
%  if 0
%  load('../output/Data_PhotonPair_g2.mat')

fz1=48;fz2=36;lw=2;
figure();

rm =1; w_p = 0.3; h_p =0.28; 

% AC =[0.4706    0.9961    0.8784]; % arrow color
% AC = [0.3412    0.7451    0.5216];
% AC = [0.6706    0.8627    0.8392];
AC = [0.9882    0.9098    0.8471];

% load('../Data/Data_Fig3.mat')
% fname=['./Fig3' '.pdf'];


load('../Data/Data_Fig4.mat')
fname=['./Fig4' '.pdf'];

%%      m = 0

subplot('position',[0.03,0.65,w_p,h_p])                     
imagesc(P1)
colormap(gray);
grid off;
set(gca,'Visible','off');


   
subplot('position',[0.03,0.35,w_p,h_p])                     
imagesc(C1)
colormap(gray);
grid off;
set(gca,'Visible','off');


subplot('position',[0.03,0.05,w_p,h_p])                     
imagesc(S1)
colormap(gray);
grid off;
set(gca,'Visible','off');




%%      m =1

subplot('position',[0.35,0.65,w_p,h_p])                     
imagesc(P2)
colormap(gray);
grid off;
set(gca,'Visible','off');


   
subplot('position',[0.35,0.35,w_p,h_p])                     
imagesc(C2)
colormap(gray);
grid off;
set(gca,'Visible','off');


subplot('position',[0.35,0.05,w_p,h_p])                     
imagesc(S2)
colormap(gray);
grid off;
set(gca,'Visible','off');




%%      m =2

subplot('position',[0.68,0.65,w_p,h_p])                     
imagesc(P3)
colormap(gray);
grid off;
set(gca,'Visible','off');


   
subplot('position',[0.68,0.35,w_p,h_p])                     
imagesc(C3)
colormap(gray);
grid off;
set(gca,'Visible','off');


subplot('position',[0.68,0.05,w_p,h_p])                     
imagesc(S3)
colormap(gray);
grid off;
set(gca,'Visible','off'); 






%%
set(gcf,'PaperSize',[21 16],'PaperPosition',[0.5, 0.5, 20, 15]);
saveas(gcf, fname);

% end