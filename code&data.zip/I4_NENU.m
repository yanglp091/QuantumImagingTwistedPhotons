clc;
clear all;
load('C:\Users\25415\Desktop\NENU')
%%
%����
theta_str = '0.2';
lambda = 1; %circular polarization
kzc = 1; %center wave vector z
thetac= pi*str2double(theta_str); % uniform polar angle pi/3; pi/20
kvc = kzc*tan(thetac); % projection of k in xy-plane
C0 = 100; % ratio of k and its width Delta_k
sigma_r = C0/kvc; % sigma_rho
sigma_z = C0; % simga_z=c*tau_p 
V_p=sigma_z*sigma_r^2;
z=10;
t=0;
m=1;
%%%%%%����
nx =1053;
ny=1053;
xlist=linspace(0.1,1,nx);
ylist=linspace(0.1,1,ny);
ymat = zeros(nx,ny);
for j=1:ny
    y=ylist(j);
     for k =1:nx
          x = xlist(k);
          %Quantum structured light: Non-classical spin texture of twisted single-photon pulses(181)
            ymat(j,k)=abs((C0/(2*pi*V_p))^0.5*1i^m.*besselj(m,kvc.*(x.^2+y.^2).^0.5).*exp(1i.*m.*atan(y./x)).*exp(-(-z.*cos(thetac)).^2./(4.*sigma_z.^2.*(cos(thetac)).^2)-1i.*kzc.*z)).^2.*exp(1i.*(-2*m.*atan(y./x)-data(j,k)));%I4+/I3-
            %ymat(j,k)=abs((C0/(2*pi*V_p))^0.5*1i^m.*besselj(m,kvc.*(x.^2+y.^2).^0.5).*exp(1i.*m.*atan(y./x)).*exp(-(-z.*cos(thetac)).^2./(4.*sigma_z.^2.*(cos(thetac)).^2)-1i.*kzc.*z)).^2;
     end
end
ymat1=ymat;
I1=trapz(ymat);
I4=abs(trapz(I1));%trapz:������ֵ����

%%����
w_p = 0.3; h_p =0.38;
mlist =1:6;
nx =1053;ny=1053;
xlist=linspace(-6,6,nx);
ylist=linspace(-6,6,ny);
g2mat = zeros(nx,ny);
g2cell = cell(2,3);
for n=1:6
    m = mlist(n);
    
    for j=1:ny 
        y=ylist(j);
        for k =1:nx
           x = xlist(k);
           g2mat(j,k) = 0.5*I4*(cos(2*m*atan(y./x)+data(j,k)));%re-scaled signal s_d
           
        end  
    end

    g2cell{2,n} = g2mat;
end

[X,Y]=meshgrid(xlist,ylist);


%%      m = 1

subplot(2,3,1)                     
surf(X,Y,real(g2cell{2,1}))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray))
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);

   
%%     m =2 
subplot(2,3,2)                     
surf(X,Y,real(g2cell{2,2}))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray));
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);


%%  m = 3
subplot(2,3,3)                     
surf(X,Y,real(g2cell{2,3}))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray));
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);

%%      m = 4

subplot(2,3,4)                     
surf(X,Y,real(g2cell{2,4}))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray));
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);

   
%%     m =5
subplot(2,3,5)                     
surf(X,Y,real(g2cell{2,5}))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray));
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);


%%  m = 6
subplot(2,3,6)                     
surf(X,Y,real(g2cell{2,6}))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray));
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);
h=colorbar('Ticks',0:0.2:1,'TickLabels','');
set(h,'location','east','position',[0.9765 0.33 0.02 0.4]);
set(h,'TickLength',0.04,'Linewidth',2,'color',[0.871,0.49,0])

set(gcf,'PaperSize',[21 16],'PaperPosition',[0.5, 0.5, 20, 15]);






%%ԭͼ
w_p = 0.3; h_p =0.38;
mlist =1:3;
nx =1053;ny=1053;
xlist=linspace(-6,6,nx);
ylist=linspace(-6,6,ny);
g2mat = zeros(nx,ny);
load('C:\Users\25415\Desktop\NENU')
m=0;
    
    for j=1:ny 
        y=ylist(j);
        for k =1:nx
           x = xlist(k);
           g2mat(j,k) = 0.5*I4*(cos(2*m*atan(y./x)+data(j,k)));           
        end  
    end
    g2mat1=g2mat;


[X,Y]=meshgrid(xlist,ylist);


%%      m = 0

figure(11)                  
surf(X,Y,real(g2mat1))
shading interp;
view([0,270]);
colormap(gray);
% colormap(flipud(gray))
grid off;
ylabel('$y/\lambda$','interpreter','latex','fontsize',16);
xlabel('$x/\lambda$','interpreter','latex','fontsize',16);
