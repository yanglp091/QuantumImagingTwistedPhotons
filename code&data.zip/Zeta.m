function output = Zeta(para,x,y)
% This function is used to evalutate the zeta function defined in the note

    thetac = para.thetac; % polar angle of the Bessel pulse
    sigmar = para.sigmar; % size of the cross-section of the pulse
    Sinv = sqrt(2/pi)*2*pi*sin(thetac)/sigmar; % the inverse of the effect area, where we have used k_c = 2pi/lambda_c
    rho = sqrt(x^2+y^2);
    beta = 2*pi*sin(thetac);
    m = para.m;
    
    output = Sinv*(besselj(m,beta*rho))^2;

end