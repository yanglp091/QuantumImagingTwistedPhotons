function output = phasefactor(para,i,j)

    Phi_mat = para.nenu;
    Phi = Phi_mat(i,j);
    output = exp(-1i*Phi);

end
