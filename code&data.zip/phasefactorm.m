function output = phasefactorm(para,i,j)

    Phi_mat = para.nenu;
    Phi = Phi_mat(i,j);
    
    pitch = para.pitch;
    nrow = para.nrow;
    ncol = para.ncol;
    x = -pitch*(nrow-1)/2+i*20;
    y = pitch*(ncol-1)/2-j*20;
    rho = sqrt(x^2+y^2);
    
    if rho>0
    
        Cosphi = x/rho;
        Sinphi = y/rho;
    else
        Cosphi =1;
        Sinphi =0;
        
    end
    
    
    m = 2* para.m;
    output = (Cosphi-1i*Sinphi)^m *exp(-1i*Phi);

end