function output = vecnorm3(array)
% this function is used to evaluate the norm of a three-dimensional data
% array along the third dimension

% array is the target dara array



        dimvec = size(array);
        output = zeros(dimvec(1),dimvec(2));
        for i = 1:dimvec(1)
            for j = 1:dimvec(2)
                vec1 = array(i,j,:);
                vec = [vec1(1,1,1), vec1(1,1,2), vec1(1,1,3)];
                output(i,j) = norm(vec); 
  
            end
                       
        end
        

        
end